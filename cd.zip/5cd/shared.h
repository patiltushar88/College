#ifndef SHARED_H
#define SHARED_H

#define MAX_VARNAME_LENGTH 10

#endif // SHARED_H

